package com.infosys.infymarket.order.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infosys.infymarket.order.dto.OrderDTO;
import com.infosys.infymarket.order.exception.InfyMarketException;
import com.infosys.infymarket.order.service.OrderService;

@RestController
@CrossOrigin
@RequestMapping
public class OrderController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	Environment environment;
	@Autowired
	private OrderService orderservice;

	@RequestMapping(value = "/api/orders/{orderid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<OrderDTO>> getSpecificOrder(@PathVariable String orderid) throws InfyMarketException {
		try {
			logger.info("Order details {}", orderid);
			List<OrderDTO> orders = orderservice.getSpecificOrder(orderid);
			return new ResponseEntity<>(orders, HttpStatus.OK);
		} catch (Exception exception) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(exception.getMessage()),
					exception);
		}

	}

//	@GetMapping(value = "/api/orders", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<List<OrderDTO>> getAllOrder() throws InfyMarketException {
//		try {
//			logger.info("Fetching all products");
//			List<OrderDTO> orderdto = orderservice.getAllOrder();
//			return new ResponseEntity<>(orderdto, HttpStatus.OK);
//		} catch (Exception exception) {
//			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(exception.getMessage()),
//					exception);
//		}
//
//	}
//
//	@PostMapping(value = "/api/orders/placedorders", consumes = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<String> addOrder(@Valid @RequestBody OrderDTO order) throws InfyMarketException {
//		try {
//			String buyerid = orderservice.addOrder(order);
//			String successMessage = environment.getProperty("API.INSERT_SUCCESS") + buyerid;
//			return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
//		} catch (Exception exception) {
//			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(exception.getMessage()),
//					exception);
//		}
//	}
	
	@RequestMapping(value = "/orders/placeorders", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> searchBuyer(@RequestBody OrderDTO orderDTO) throws InfyMarketException{
		try {
			String orderid = orderservice.saveBuyer(orderDTO);
			String successMessage = environment.getProperty("API.ORDER_SUCCESS") + orderid;
			return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
		} catch(Exception exception) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, environment.getProperty(exception.getMessage()),
					exception);
		}
//		return orderservice.saveBuyer(orderDTO);
	}

}
